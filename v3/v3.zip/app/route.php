<?php
// switch (getURI()) {
//     case '':
//         return require 'app/view/order/index.php';
//         break;
//     case '/':
//         return require 'app/view/order/index.php';
//         break;
//     case 'api/cart':
//         return require _DIR_PATH_('app/api/cart.php');
//         break;
//     case 'order/invoice?orderID=' . $_GET['orderID'] ?? $_GET['orderID'] = null:
//         return require _DIR_PATH_('app/view/order/invoice.php');
//         break;
        
//     default:
//         print 'not found';
//         break;
// }